 


<!DOCTYPE html> 
<html lang="en">
<head>



<style type="text/css">
    
img {
	float: center;
	width: 300px;
	height: 100px;
	border-radius: 0%;
	shape-outside: circle();
	shape-margin: 15px;
	}

    
</style>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="mobile-web-app-capable" content="yes">
    

    

    <!-- Bootstrap core CSS -->
    <link href="bootstrap-3.3.5-dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap-3.3.5-dist/css/custom.css" rel="stylesheet">
    <link rel="icon" sizes="192x192" href="logo.jpg?1667779635">


	<title>Naufal Bisnes</title>


        <div id="top" style="position:fixed;background:linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1)) ;top:0;left:0;right:0;width:100%;">
        <center><font size="6"face="verdana" color="white">Naufal Bisnes</font></center><br>
      
        </div>

        <div id="bottom" style="position:fixed;background:linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1)) ;bottom:0;left:0;right:0;width:100%;">
        <center><font size="3"face="verdana" color="white">zz-automation.com</font></center><br>
        </div>





<script type="text/javascript">
function validateForm()
{
var a=document.forms["myForm"]["login"].value
var b=document.forms["myForm"]["password"].value


  if (a==null || a=="")
  {
  alert("Please input login");
  return false;
  }

  if (b==null || b=="")
  {
  alert("Please input password");
  return false;
  }

}

</script>

  
</head>



<br>
<br>


<div><center><img src="logo.jpg?1667779635" </div > </center>

<div class="container">
<div class="login">


   
    <form  class="form-signin" name="myForm" action="insert_login.php" onsubmit="return validateForm()" method="post">
    <h2 class="form-signin-heading">Please sign in</h2>

    			
        	
                <label for="inputEmail" class="sr-only">Email address</label>
        	<input type="text" class="form-control" name="login"  placeholder="Username or email">
          	

        	<label for="inputPassword" class="sr-only">Password</label>
          	<input type="password" class="form-control"  name="password"  placeholder="Password">
        	 
                  
                 <div class="checkbox"  >
                  <label>
                  
                     <input type="checkbox" value="remember-me" style="left:20px" > Remember me 
                  
                  </label>
                </div>
                
                 
          	<input type="text" class="form-control"  name="ipadd" value= "180.74.50.125" readonly >

               
        	
        	<button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
       		</form>
 		
</div>

<center>
<tr><td> Licence Due </td><td> <input type="text"   name="ipadd" value= "2023-07-18" style="width: 90px" readonly >
<tr><td> Days.Bal </td><td> <input type="text"   name="ipadd" value= "260" style="width: 40px" readonly >
<tr><td> Cr.Limit </td><td> <input type="text"   name="ipadd" value= "0" style="width: 40px" readonly >

</div>

</center>
</form>


<br><font size='4' face='verdana' color='Red'><center><b><u>
</body>

</html>